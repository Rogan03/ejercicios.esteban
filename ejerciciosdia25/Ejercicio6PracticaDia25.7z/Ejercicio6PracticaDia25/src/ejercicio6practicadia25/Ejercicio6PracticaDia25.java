/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6practicadia25;

import entidades.Curso;

/**
 *
 * @author Esteban
 */
public class Ejercicio6PracticaDia25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Curso cursito = new Curso();
        cursito.calcularGananciaSemanal(cursito.crearCurso());
    }
    
}
