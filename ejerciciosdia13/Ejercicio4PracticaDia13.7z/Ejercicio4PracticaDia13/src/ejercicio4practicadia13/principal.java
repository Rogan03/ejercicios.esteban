/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4practicadia13;

import entidades.Rectangulo;

/**
 *
 * @author ESTEBAN
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rectangulo dibujo = new Rectangulo();
        dibujo.pregunta();
        dibujo.mostrarCosas();
    }
}
