/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circunferencia;

import entidad.Circunferencia;

/**
 *
 * @author ESTEBAN
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circunferencia ejercicio2 = new Circunferencia();
        ejercicio2.crearCircunferencia();
        ejercicio2.crearArea();
        ejercicio2.crearPerimetro();
    }
}
