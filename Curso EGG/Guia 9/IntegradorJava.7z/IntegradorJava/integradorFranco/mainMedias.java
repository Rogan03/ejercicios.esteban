package mains;

import entidad.Medias;
import servicios.ServiceMedias;

public class mainMedias {

    public static void main(String[] args) {
        ServiceMedias sc = new ServiceMedias();
        Medias m1 = sc.crearCadena();
        sc.llenado(m1);
        System.out.println("- - - - -");
        sc.mostrar(sc.getCad());
        System.out.println("");
        System.out.println("- - - - -");
        sc.repetir();
        System.out.println("Medias amigas =");
        sc.mostrar(sc.getResult());
        System.out.println("");
    }

}
