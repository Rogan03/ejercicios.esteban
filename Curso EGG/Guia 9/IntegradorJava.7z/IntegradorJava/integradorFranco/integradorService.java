/*
cant caramelos
cant de presos
num de preso inicial
resultado
 */
package servicios;

import entidad.Integrador;
import java.util.Arrays;
import java.util.Scanner;

public class integradorService {

    static Scanner leer = new Scanner(System.in).useDelimiter("\n");

    private int [] result;
    private int [] cantp;
    private int [] cantc;

    public int[] getResult() {
        return result;
    }

    public void setResult(int[] result) {
        this.result = result;
    }

    public int[] getCantp() {
        return cantp;
    }

    public void setCantp(int[] cantp) {
        this.cantp = cantp;
    }

    public int[] getCantc() {
        return cantc;
    }

    public void setCantc(int[] cantc) {
        this.cantc = cantc;
    }
     
    public Integrador crearPresos() {

        System.out.println("ingrese la cantidad de presos");
        int cantP = leer.nextInt();
        while (cantP < 0) {
            System.out.println("ingrese correctamente la cantidad de presos");
            cantP = leer.nextInt();
        }
        System.out.println("ingrese la cantidad de caramelos");
        int cantC = leer.nextInt();
        while (cantC < 0) {
            System.out.println("ingrese correctamente la cantidad de caramelos");
            cantC = leer.nextInt();
        }
        System.out.println("ingrese el preso inicial");
        int presoI = leer.nextInt();
        while (presoI < 0) {
            System.out.println("ingrese correctamente el preso inicial");
            presoI = leer.nextInt();
        }
//confirmo que todos los numeros sean positivos

        return new Integrador(cantC, cantP, presoI);
    }

    public void crearJuego(Integrador i1) {
        int contI = i1.getPresoInicial();
        
        llenadoC(i1);
        llenadoP(i1);
         // y en este for hago lo del llamado pero no funciona, tira siempre el ultimo preso
         // sirve para el proposito pero no para lo que yo queria mostrar
         // para arreglarlo creo que tendria que pasarle la posicion y crear antes un array
         //para ir llenandolo asi pero cumple la funcion asique ahi se queda
        for (int i = 0; i < i1.getCaramelos(); i++) {
            if (contI == i1.getPresos()) {
                contI = 0;
            }
            llenadoResult(i1,contI);
            contI++;
        }
    }
   
    public void llenadoC(Integrador i1){
        //hago este metodo para contar los caramelos
        int [] c1 = new int [i1.getCaramelos()];
        for (int i = 0; i < c1.length; i++) {
            c1 [i] = i;
        }
        this.cantc = c1;
    }
     public void llenadoP(Integrador i1){
         //hago este otro para la cantidad de presos
        int [] p1 = new int [i1.getPresos()];
        for (int i = 0; i < p1.length; i++) {
            p1 [i] = i;
        }
        this.cantp = p1;
    }
     public void llenadoResult(Integrador i1, int r1){
         int [] ca = new int [i1.getCaramelos()];
         //este otro se supone que es para poner el numero de preso que le toca ese caramelo
         for (int i = 0; i < i1.getCaramelos(); i++) {
             ca [i] = cantp[r1]; 
         }
         this.result = ca;
     }
     public void mostrar(int [] a1){
         System.out.println(Arrays.toString(a1));
     }
}
