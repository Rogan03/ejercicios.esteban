/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import entidad.Capicua;
import java.util.Arrays;
import java.util.Scanner;

public class ServiceCapicua {

    static Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Capicua crearCapi() {
        System.out.println("ingrese el numero para comparar");
        int l1 = leer.nextInt();
        return new Capicua(l1);
    }

    public boolean resultado(Capicua c1) {
        //paso el int a un string con valor absoluto para evitar lo del menos si tiene
        String aux = String.valueOf(Math.abs(c1.getCapic()));
        //creo 2 vectores segun la longitud del string, uno para el normal y otro para el reves
        String[] cad = new String[aux.length()];
        String[] cad2 = new String[aux.length()];
        auxllenado(aux, cad);
        auxllenado2(cad, cad2);
        //uso lo del comparar arrays para los vectores
        boolean b1 = Arrays.equals(cad, cad2);
        return b1;
    }

    public void auxllenado(String fr, String[] lt) {
        int cont = 1;
        for (int i = 0; i < fr.length(); i++) {
            lt[i] = fr.substring(i, cont);
            cont++;
        }
    }

    public void auxllenado2(String [] lt, String [] lt2){
         int cont = (lt.length-1);
        for (int i = 0; i < lt.length; i++) {
            lt2[i] = lt[cont];
            cont--;
        }
    }
    public void mostrar(String []fr){
        System.out.println(Arrays.toString(fr));
    }
}
