/*
cant caramelos
cant de presos
num de preso inicial
resultado
 */
package entidad;

public class Integrador {
    private int caramelos;
    private int presos;
    private int presoInicial;
    private int resultado;

    public int getCaramelos() {
        return caramelos;
    }

    public void setCaramelos(int caramelos) {
        this.caramelos = caramelos;
    }

    public int getPresos() {
        return presos;
    }

    public void setPresos(int presos) {
        this.presos = presos;
    }

    public int getPresoInicial() {
        return presoInicial;
    }

    public void setPresoInicial(int presoInicial) {
        this.presoInicial = presoInicial;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    public Integrador(int caramelos, int presos, int presoInicial) {
        this.caramelos = caramelos;
        this.presos = presos;
        this.presoInicial = presoInicial;
    }

    public Integrador() {
    }
}
