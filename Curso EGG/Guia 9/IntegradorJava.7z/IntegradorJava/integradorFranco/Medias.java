/*
En un universo paralelo, donde los habitantes son medias, existe un crucero de medias 
donde se sube una lista de medias. Esta lista de tripulantes del crucero es una Collection 
de letras. 
Lo que se deberá hacer, es filtrar la lista de medias que se suben al crucero y retornar una 
lista que contenga los grupos de medias que si tenían pares. Esta lista final de medias 
pares se mostraran ordenadas de menor a mayor.
A continuación un ejemplo: 
List de medias que llegan : A,B,A,B,C,A,F,Z,C,H. A,B y C tiene pares, mientras que F,Z y H no.
Entonces la List que se debería retornar sería: A,B,C


por lo que llegue a entender es cuando se repite una letra, que la lista retorna algo
 */
package entidad;

public class Medias {
    private String cadena;

    public Medias() {
    }

    public Medias(String cadena) {
        this.cadena = cadena;
    }

    public String getCadena() {
        return cadena;
    }

    public void setCadena(String cadena) {
        this.cadena = cadena;
    }
    
}
