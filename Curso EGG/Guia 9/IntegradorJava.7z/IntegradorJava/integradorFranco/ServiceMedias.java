package servicios;

import entidad.Medias;
import java.util.Arrays;
import java.util.Scanner;

public class ServiceMedias {

    static Scanner leer = new Scanner(System.in).useDelimiter("\n");
    private String[] cad;
    private String[] result;
    private int longitud;

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    public String[] getCad() {
        return cad;
    }

    public void setCad(String[] cad) {
        this.cad = cad;
    }

    public String[] getResult() {
        return result;
    }

    public void setResult(String[] result) {
        this.result = result;
    }

    public Medias crearCadena() {
        System.out.println("ingrese una frase");
        String frase = leer.next();
        this.longitud = frase.length();
        return new Medias(frase);
    }

    public void llenado(Medias m1) {
        //en este metodo lleno el array
        String c1 = m1.getCadena();
        String[] fr = new String[longitud];
        int cont = 1;
        for (int i = 0; i < longitud; i++) {
            fr[i] = c1.substring(i, cont);
            cont++;
        }
        this.cad = fr;
    }

    public void auxllenado() {
        String[] c1 = new String[longitud];
        result = c1;
        Arrays.fill(result, "qw");
        //lo lleno de esta manera para asi solo tomar lo de un digito cuando lo voy reemplazando
    }

    public void mostrar(String[] fr) {
        for (String fr1 : fr) {
            //lo mismo a la hora de mostrarlo
            if (!fr1.equals("qw")) {
                System.out.print("[" + fr1 + "]");
            }
        }
    }

    public void repetir() {
        auxllenado();
        int cont = 0;
        int contCad = 0;
        String aux = " ";
        do {
            for (int i = 0; i < longitud; i++) {
                //este if es para ver cuantas veces se repitio una letra
                if (cad[i].equals(cad[cont])) {
                    contCad++;
                    aux = cad[i];
                    //el aux lo usamos para guardar la letra
                }
            }
            if (contCad >= 2) {
//si se repitio 2 veces o mas le pasamos esa letra
                auxresult(aux);
            }
            if (contCad > 0) {
                contCad = 0;
            }
            cont++;
        } while (cont != longitud);
    }

    public void auxresult(String fr) {
        int cont;
        int lt = 0;
        /*
        en este for la verdad no me acuerdo que hice pero creo que era para comparar que esa letra que paso si ya esta en el array
        no escribirla de vuelta o algo asi, y el break es para terminar con el bucle y no llenar todo el array
        */
        for (int f = 0; f < longitud; f++) {
            cont = 0;
            if (result[f].equals(fr)) {
                lt = 1;
            }

            if (result[f].equals("qw")) {
                cont = 1;
            }
            if (cont == 1 && lt == 0) {
                result[f] = fr;
                break;
            }
            
        }
    }
}
