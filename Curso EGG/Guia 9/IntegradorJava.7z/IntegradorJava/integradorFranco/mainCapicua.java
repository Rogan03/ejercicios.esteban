
package mains;

import entidad.Capicua;
import servicios.ServiceCapicua;

public class mainCapicua {

    public static void main(String[] args) {
      ServiceCapicua sc = new ServiceCapicua();
      Capicua c1 = sc.crearCapi();
      boolean b1 = sc.resultado(c1);
        System.out.println("es un numero capicua ? " + b1);
    }
    
}
