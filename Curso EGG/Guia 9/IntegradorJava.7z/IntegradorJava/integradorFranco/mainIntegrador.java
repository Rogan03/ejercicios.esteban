
package mains;

import entidad.Integrador;
import servicios.integradorService;

public class mainIntegrador {

    public static void main(String[] args) {
       integradorService i1 = new integradorService();
       Integrador a1 = i1.crearPresos();
       i1.crearJuego(a1);
        i1.mostrar(i1.getCantc());
        System.out.println("___");
        i1.mostrar(i1.getCantp());
        System.out.println("___");
        i1.mostrar(i1.getResult());
    }
    
}
